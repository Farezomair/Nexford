# Using necessary library for random data
library(jsonlite)
# Step 1: Creating a list of 400 workers dynamically
num_workers <- 400
set.seed(123) # for reproducibility of data in variable
# Using a loop to create 400 workers with random salaries and genders
workers <- data.frame(
  id = integer(),
  salary = integer(),
  gender = character(),
  stringsAsFactors = FALSE
)
for (i in 1:num_workers) {
  salary <- sample(7500:30000, 1)  # Generating a random salary between 7500 and 30000
  gender <- sample(c('Male', 'Female'), 1)  # Randomly choosing gender
  workers <- rbind(workers, data.frame(id = i, salary = salary, gender = gender, stringsAsFactors = FALSE))
}
# Step 2: Generating payment slips for 400 workers
payment_slips <- data.frame(worker_id = integer(), salary = integer(), gender = character(), employee_level = character(), stringsAsFactors = FALSE)
# Using a loop to generate payment slips with their id, salary, gender, and employee level
for (i in 1:nrow(workers)) {
  worker_id <- workers$id[i]
  salary <- workers$salary[i]
  gender <- workers$gender[i]
  employee_level <- NA
  # Step 3: Making Conditional statements to assign employee levels
  if (salary > 10000 && salary < 20000) {
    employee_level <- 'A1'
  }
  if (salary > 7500 && salary < 30000 && gender == 'Female') {
    employee_level <- 'A5-F'
  }
  # Generating unique payment slip for each worker along with their employee levels
  payment_slips <- rbind(payment_slips, data.frame(worker_id = worker_id, salary = salary, gender = gender, employee_level = employee_level, stringsAsFactors = FALSE))
}
# Error handling in our code
tryCatch({
  print(payment_slips)
}, error = function(e) {
  print("Sorry! Contact Muhammad Farez Omair for help")
})
