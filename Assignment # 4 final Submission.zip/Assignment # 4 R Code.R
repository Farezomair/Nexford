# loading the dataset into R and importing library
df <- read.csv("C:/Users/Farez Laptop/Dropbox/My PC (DESKTOP-0DN7O4V)/Desktop/Assignment # 4/Netflix_shows_movies/Netflix_shows_movies.csv")
library(ggplot2)
# plot for Most watched genres
top_genres <- head(sort(table(df$listed_in), decreasing = TRUE), 10)
top_genres <- as.data.frame(top_genres)
names(top_genres) <- c('Genre', 'Count')
ggplot(top_genres, aes(x=reorder(Genre, -Count), y=Count)) +
  geom_bar(stat='identity', fill='red', color='white') +
  labs(title='Top 10 Most Watched Genres on Netflix',
       x='Genres',
       y='Number of Shows/Movies') +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))





