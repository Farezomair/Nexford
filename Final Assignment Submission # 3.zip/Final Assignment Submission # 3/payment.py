class Payment:
    def __init__(self, payment_id, policyholder, amount, status='Pending'):
        self.payment_id = payment_id
        self.policyholder = policyholder
        self.amount = amount
        self.status = status

    def process(self):
        self.status = 'Completed'
        print(f"Payment {self.payment_id} processed for {self.policyholder.name}.")

    def send_reminder(self):
        if self.status == 'Pending':
            print(f"Reminder: Payment {self.payment_id} is pending for {self.policyholder.name}.")

    def apply_penalty(self):
        if self.status == 'Pending':
            penalty = self.amount * 0.05  # 5% penalty
            self.amount += penalty
            print(f"Penalty applied to payment {self.payment_id}. New amount: {self.amount}")

    def display_details(self):
        print(f"Payment ID: {self.payment_id}, Policyholder: {self.policyholder.name}, Amount: {self.amount}, Status: {self.status}")
