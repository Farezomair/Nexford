class Product:
    def __init__(self, product_id, name, description, active=True):
        self.product_id = product_id
        self.name = name
        self.description = description
        self.active = active

    def create(self):
        self.active = True
        print(f"Product {self.name} created.")

    def update(self, name=None, description=None):
        if name:
            self.name = name
        if description:
            self.description = description
        print(f"Product {self.name} updated.")

    def remove(self):
        self.active = False
        print(f"Product {self.name} removed.")

    def display_details(self):
        status = 'Active' if self.active else 'Suspended'
        print(f"Product ID: {self.product_id}, Name: {self.name}, Description: {self.description}, Status: {status}")
