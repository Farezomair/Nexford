class Policyholder:
    def __init__(self, policyholder_id, name, age, active=True):
        self.policyholder_id = policyholder_id
        self.name = name
        self.age = age
        self.active = active
        self.policies = []

    def register(self):
        self.active = True
        print(f"Policyholder {self.name} registered.")

    def suspend(self):
        self.active = False
        print(f"Policyholder {self.name} suspended.")

    def reactivate(self):
        self.active = True
        print(f"Policyholder {self.name} reactivated.")

    def add_policy(self, policy):
        self.policies.append(policy)
        print(f"Policy {policy.name} added to policyholder {self.name}.")

    def display_details(self):
        status = 'Active' if self.active else 'Suspended'
        print(f"Policyholder ID: {self.policyholder_id}, Name: {self.name}, Age: {self.age}, Status: {status}")
        for policy in self.policies:
            policy.display_details()
