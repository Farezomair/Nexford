from policyholder import Policyholder
from product import Product
from payment import Payment

# Create products
product1 = Product(product_id=1, name="Health Insurance", description="Covers medical expenses.")
product2 = Product(product_id=2, name="Life Insurance", description="Provides life cover.")

# Register products
product1.create()
product2.create()

# Create policyholders
policyholder1 = Policyholder(policyholder_id=1, name="Alice", age=30)
policyholder2 = Policyholder(policyholder_id=2, name="Bob", age=40)

# Register policyholders
policyholder1.register()
policyholder2.register()

# Add policies to policyholders
policyholder1.add_policy(product1)
policyholder2.add_policy(product2)

# Process payments
payment1 = Payment(payment_id=1, policyholder=policyholder1, amount=100)
payment2 = Payment(payment_id=2, policyholder=policyholder2, amount=200)

payment1.process()
payment2.process()

# Display details
policyholder1.display_details()
policyholder2.display_details()
payment1.display_details()
payment2.display_details()
